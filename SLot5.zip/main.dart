//may tinh dien tu
import 'package:flutter/material.dart';
void main(){
  runApp(CalculatorApp());
}
class CalculatorApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Slot 5_2',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: CalculatorScreen(),
    );
  }
}
class CalculatorScreen extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return _CalculatorScreenState();
  }
}
class _CalculatorScreenState extends State<CalculatorScreen>{
  String displayText = '';//hien thi text
  double num1 = 0;
  double num2 = 0;
  String operation = '';//phep tinh
  bool shouldClearDisplay = false;
  //ham xu ly khi nguoi dung nhan vao SO
  void onDigitPress(String digit){
    setState(() {
      displayText='';
      shouldClearDisplay=false;
    });
    displayText +=digit;
  }
  //xu ly khi nguoi dung nhan vao phep tinh
  void onOprerationPress(String newOperation){
    setState(() {
      num1 = double.parse(displayText);
      operation=newOperation;
      shouldClearDisplay=true;
    });
  }
  //tinh gia tri bieu thuc
  void onEqualsPress(){
    setState(() {
      num2 = double.parse(displayText);
      switch(operation){
        case '+':
          displayText=(num1+num2).toString();
          break;
        case '-':
          displayText = (num1-num2).toString();
          break;
        case '*':
          displayText=(num1*num2).toString();
          break;
        case '/':
          if(num2 != 0){
            displayText=(num1/num2).toString();
          }
          else {
            displayText='Error';
          }
          break;
        default:
          break;
      }
      shouldClearDisplay=true;
    });
  }
  //ham xu ly sau khi tinh toan xong
  void onClearPress(){
    setState(() {
      displayText='';
      num1=0;
      num2=0;
      operation='';
      shouldClearDisplay=false;
    });
  }
 @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Calculation'),),
      body: Column(
        children: [
          Expanded(
              child: Container(
                padding: EdgeInsets.all(15.0),
                color: Colors.purpleAccent,
                alignment: Alignment.bottomRight,
                child: Text(
                  displayText,
                  style: TextStyle(fontSize: 30,color: Colors.white),),
              )),
            buildButtonRow(['7','8','9','/'], onDigitPress, onOprerationPress),
            buildButtonRow(['4','5','6','*'], onDigitPress, onOprerationPress),
            buildButtonRow(['1','2','3','-'], onDigitPress, onOprerationPress),
            buildButtonRow(['0','.','=','+'], onDigitPress, (value){
              if(value == '='){
                onEqualsPress();
              }
              else {
                onOprerationPress(value);
              }
            }),
            Container(
              color: Colors.black,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  ElevatedButton(onPressed: onClearPress, child: Text('C'),),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
//dinh nghia widget
Widget buildButtonRow(
List<String> buttons,
Function(String) onDigitPress,
Function(String) onOprerationPress){
  return Container(
    color: Colors.black,
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: buttons.map((button)=>
          ElevatedButton(
              onPressed: (){
                if(button == '+' || button == '-' || button== '*' || button == '/' || button == '='){
                  onOprerationPress(button);
                }
                else {
                  onDigitPress(button);
                }
              },
              child: Text(
                button,
                style: TextStyle(fontSize: 25.0),
              ),),).toList(),
    ),
  );
}