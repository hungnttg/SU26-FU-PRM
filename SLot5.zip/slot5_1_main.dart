//listview with objects
import 'dart:ui';

import 'package:flutter/material.dart';
//ham main
void main5_1(){
  runApp(const MyApp());//goi fil cau hinh
}
class MyApp extends StatelessWidget{
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SLot 5',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.purpleAccent),
        useMaterial3: true,
    ),
      home: MyListviewObject(),//goi den man hinh chinh
    );
  }
}
//dinh nghia man hinh chinh
class MyListviewObject extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return _MyListviewObjectState();//lop quan ly trang thai cua man hinh chinh
  }
}
//dinh nghia lop quan ly trang thai cua man hinh chinh
class _MyListviewObjectState extends State<MyListviewObject>{
  // du lieu mang cac doi tuong
  final List<ListItem> items = [
    ListItem(title: "title 1", subtitle: "subtitle 1"),
    ListItem(title: "title 2", subtitle: "subtitle 2"),
    ListItem(title: "title 3", subtitle: "subtitle 3"),
    ListItem(title: "title 4", subtitle: "subtitle 4"),
    ListItem(title: "title 5", subtitle: "subtitle 5"),
    ListItem(title: "title 6", subtitle: "subtitle 6"),
    ListItem(title: "title 7", subtitle: "subtitle 7"),
    ListItem(title: "title 8", subtitle: "subtitle 8"),
    ListItem(title: "title 9", subtitle: "subtitle 9"),
    ListItem(title: "title 10", subtitle: "subtitle 10"),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
    appBar: AppBar(title: Text('Listview Object SLot 5'),),
    body: ListView.builder(
      itemCount: items.length,//so luong item
      itemBuilder: (context,index){
        return ListTile(
          title: Text(items[index].title),
          subtitle: Text(items[index].subtitle),
          onTap: (){
            //xu ly su kien khi item duoc chon
            print('Item clicked: ${items[index].title}');
            } ,
        );
  }),
    );
  }
}
//dinh nghia
class ListItem{
  final String title;
  final String subtitle;
  ListItem({required this.title,required this.subtitle});
}