//npm i express mysql2 cors
//xay dung server cho Flutter
//b1. import thu vien
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
//b2- tao server va cau hinh
const server = express();
server.use(express.json());//cho phep su dung json
server.use(cors());//cho phep flutter ket noi den
//b3- ket noi csdl
const database = mysql.createConnection({
    host:"localhost",
    user: "root",
    password:"",
    database:"shop"
});
//b4. xay dung cac API
//hien thi
server.get("/products",(req,res)=>{
    database.query(
        "SELECT * FROM products",(e,r)=>res.json(r)
    );
});
//insert
server.post("/products",(req,res)=>{
    database.query(
        "INSERT INTO products (name) VALUES (?)",[req.body.name]
    );
    res.json({msg:"added"});//da them thanh cong
});
//sua
server.put("/products/:id",(req,res)=>{
    database.query(
        "UPDATE products SET name=? WHERE id=?",
        [req.body.name,req.params.id]
    );
    res.json({msg:"Updated"});
});
//xoa
server.delete("/products/:id",(req,res)=>{
    database.query(
        "DELETE FROM products WHERE id=?",[req.params.id]
    );
    res.json({msg:"deleted"});
});
//server lang nghe flutter goi
server.listen(3001);