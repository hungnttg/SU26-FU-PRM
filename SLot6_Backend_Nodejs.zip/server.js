//npm i express (tao port lang nghe ket noi)
//npm i cors (security, cho phep client ket noi)
const express = require('express'); //import thu vien
const cors = require('cors');//import thu vien
const app= express();//tao doi tuong server
const PORT = 3000;
app.use(cors());//cho phep client ket noi
app.use(express.json());//chuyen du lieu sang json
//--du lieu mau
const items = [
    {
        title: 'Cat',
        subtitle: 'Cute cat',
        imageUrl: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=200'
    },
    {
        title: 'Dog',
        subtitle: 'Lovely dog',
        imageUrl: 'https://images.unsplash.com/photo-1517849845537-4d257902454a?w=200'
    },
    {
        title: 'Mountain',
        subtitle: 'Beautiful mountain',
        imageUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=200'
    }
];
//API lay ve listitem
app.get('/items',(req,res)=>{
    res.json(items);
});
//chay server
app.listen(PORT,()=>{console.log(`Server running at http://localhost:${PORT}`)});