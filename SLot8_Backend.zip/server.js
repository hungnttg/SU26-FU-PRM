//npm i express //tao server lang nghe ket noi tu client
//npm i mysql2 //ket noi csdl
//npm i cors //security
//b1-tham chieu thu vien
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
//b2 - tao doi tuong server,xu ly bao bat
const app =  express();
app.use(cors());
//b3. ket noi csdl mysql
const conn = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"a2"
});
conn.connect(err =>err);//thuc hien ket noi
//b4: viet cac endpoint
app.get('/data',(req,res)=>{
    //truy van du lieu
    conn.query('select * from mytable',(err,results)=>{
        if(err) throw err;
        res.json({products: results});//chuyen ket qua sang json
    });
});
//b5 - lang nghe
app.listen(3000,()=>{console.log("ung dung dang chayj o cong 3000")});
