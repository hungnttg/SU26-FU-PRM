import 'package:flutter/material.dart';
import 'api.dart';
import 'amodel.dart';
class ProductProvider extends ChangeNotifier{
  Api api = Api();
  List<Product> products = [];
  Future load() async {
    products = await api.getProducts();
    notifyListeners();
  }
  Future add(String name) async{
    await api.add(name);
    load();
  }
  Future update(int id,String name) async {
    await api.update(id, name);
    load();
  }
  Future delete(int id) async {
    await api.delete(id);
    load();
  }
}