class Product {
  int id;
  String name;
  Product({
    required this.id,
    required this.name
  });
  factory Product.fromJson(json)=> Product(
    id: json["id"],
    name: json["name"],
  );
}