import 'package:flutter/material.dart';
import 'aprovider.dart';
import 'package:provider/provider.dart';
class Home extends StatelessWidget{
  Home({super.key});
  final TextEditingController txt = TextEditingController();
  int? selectedId;
  @override
  Widget build(BuildContext context) {
    final p = Provider.of<ProductProvider>(context);
    if(p.products.isEmpty){
      p.load();
    }
    return Scaffold(
      appBar: AppBar(title: const Text("Provider"),),
      body: Column(
        children: [
          Padding(
              padding: const EdgeInsets.all(10),
              child: TextField(
                controller: txt,
                decoration: const InputDecoration(
                  hintText: "Ten san pham",
                  border: OutlineInputBorder(),
                ),
              ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton(
                  onPressed: () async {
                    await p.add(txt.text);
                  }, child: const Text("Them"),),
              ElevatedButton(
                  onPressed: () async {
                    await p.update(selectedId!, txt.text,);
                    txt.clear();
                    selectedId=null;
                  },
                  child: const Text("SUA"),),
            ],
          ),
          const Divider(),
          Expanded(
              child: ListView.builder(
                  itemCount: p.products.length,
                  itemBuilder: (_,i){
                    final item = p.products[i];
                    return ListTile(
                      title: Text(item.name),
                      onTap: (){
                        txt.text = item.name;
                        selectedId = item.id;
                      },
                      trailing: IconButton(
                          icon: const Icon(Icons.delete),
                          onPressed: (){
                            p.delete(item.id);
                          }, ),
                    );
                  })),

        ],
      ),
    );
  }
}