import 'dart:convert';
import 'package:http/http.dart' as http;
import 'amodel.dart';
class Api {
  String url="http://10.22.10.72:3001/products";
  //read data from server
Future<List<Product>> getProducts() async {
  var res = await http.get(Uri.parse(url));
  return (jsonDecode(res.body) as List)
      .map((e)=>Product.fromJson(e)).toList();
}
//add data
Future add(String name) async {
  await http.post(
    Uri.parse(url),
    headers: {
      "Content-Type":"application/json"
    },
    body: jsonEncode({
      "name":name
    }),
  );
}
//update data
Future update(int id,String name) async {
  await http.put(
    Uri.parse("$url/$id"),
    headers: {"Content-Type":"application/json"},
    body: jsonEncode({
      "name":name
    }),
  );
}
Future delete(int id) async {
  await http.delete(Uri.parse("$url/$id"),);
}
}