import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'aprovider.dart';
import 'home.dart';
void main(){
  runApp(
    ChangeNotifierProvider(
        create: (_)=>ProductProvider(),
        child: MaterialApp(
          home: Home(),
        ),
    ),
  );
}