//npm i cors express
//b1-import thu vien
const express = require('express');
//b2- tao moi server va cau hinh
const server = express();
server.use(express.json());
//b3- tao san pham vi du
let products = [
    {id:1,name:"San pham 1"},
    {id:2,name:"San pham 2"}
];
//b4- viet cac API
//GET
server.get("/products",(req,res)=>{
    res.json(products);
});
//POST
server.post("/products",(req,res)=>{
    products.push({
        id:products.length +1, //id tu tang
        name: req.body.name //lay du lieu do nguoi dung nhap
    });
    res.json({message:"Them thanh cong"});
});
//DELETE
server.delete("/products/:id",(req,res)=>{
    products = products.filter(p=>p.id != req.params.id);//xoa
    res.json({message:"Xoa thanh cong"});
});
//b5 - server lang nghe flutter goi den
server.listen(3001);