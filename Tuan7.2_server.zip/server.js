//create database shop;
//use shop;
//create table products(id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100));
//-----
//b1- cai dat thu vien
//npm i express mysql2 cors
//B1 - import thu vien
const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
//b2- tao server va cau hinh server
const server=express();
server.use(cors());//cho phep flutter ket noi
server.use(express.json());
//b3-khai bao ket noi csdl
const db = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"shop"
});
//GET: lay du lieu tu db
server.get("/products",(req,res)=>{
    db.query(
        "SELECT * FROM products",
    (err,result)=>res.json(result)
    );
});
//POST: insert du lieu vao db
server.post("/products",(req,res)=>{
    db.query(
        "INSERT INTO products (name) values (?)",
        [req.body.name]
    );
    res.json({message:"OK"});
});
//server lang nghe
server.listen(3001);