//listview
import 'package:flutter/material.dart';
//ham main
void main(){
  runApp(const MyApp());//goi den file cau hinh ung dung flutter
}
//dinh nghia file cau hinh
class MyApp extends StatelessWidget{
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
   return MaterialApp(
     title: 'Flutter SLot4',
     theme: ThemeData(
       colorScheme: ColorScheme.fromSeed(seedColor: Colors.blueGrey),
       useMaterial3: true,
     ),
     home: MyListview(),//goi den man hinh chinh
   );
  }
}
//dinh nghia man hinh chinh
class MyListview extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return _MyListviewState();//lop quan ly trang thai cua man hinh chinh
  }
}
//dinh nghia lop quan ly trang thai
class _MyListviewState extends State<MyListview>{
  //du lieu mang
  final List<String> items = [
    'Item 1',
    'Item 2',
    'Item 3',
    'Item 4',
    'Item 5',
    'Item 6',
    'Item 7',
    'Item 8',
    'Item 9',
    'Item 10',
    'Item 11',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Listview slot4'),),
      body: ListView.builder(
          itemCount: items.length,//tong so luong item
          itemBuilder: (context,index){
            return ListTile(
              title: Text(items[index]),//lay ve ten cua item
              onTap: (){
                //xu ly su kien khi 1 item duoc click
                print('Item clicked: ${items[index]}');
              },
            );
          }),
    );
  }
}