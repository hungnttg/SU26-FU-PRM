import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

Future<int> fetchUserData() async {
  await Future.delayed(Duration(seconds: 2));
  return 42;
}
void main41(){
  runApp(MyApp());
}
class MyApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: FutureBuilder<int>(
            future: fetchUserData(),
            builder: (context,snapshot){
              if(snapshot.connectionState == ConnectionState.waiting){
                return CircularProgressIndicator();
              }
              else {
                return Text('User data: ${snapshot.data}');
              }
            }),

      ),
    );
  }
}